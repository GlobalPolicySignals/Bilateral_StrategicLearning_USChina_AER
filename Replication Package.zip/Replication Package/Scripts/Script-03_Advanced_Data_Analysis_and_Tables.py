#!/usr/bin/env python3
"""
CSV Data Plotter for Academic Tables
Creates interactive plots and displays of CSV data in academic table format
"""

import matplotlib.pyplot as plt
import pandas as pd
import numpy as np
from matplotlib.patches import Rectangle
import seaborn as sns

def plot_bilateral_correlation(csv_file='table3_bilateral_correlation.csv'):
    """
    Plot Table 3: Bilateral Strategic Correlation
    """
    try:
        df = pd.read_csv(csv_file)
        
        # Create figure with subplots
        fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(15, 6))
        
        # Plot 1: Correlation by Period
        periods = df['Period'].tolist()
        correlations = df['Correlation'].tolist()
        
        # Remove NaN values for plotting
        plot_data = [(p, c) for p, c in zip(periods, correlations) if not pd.isna(c)]
        periods_clean, correlations_clean = zip(*plot_data) if plot_data else ([], [])
        
        bars = ax1.bar(periods_clean, correlations_clean, 
                      color=['#2F5597', '#4A90E2', '#7BB3F0'], alpha=0.8)
        ax1.set_title('Bilateral Strategic Correlation by Period', fontsize=14, fontweight='bold')
        ax1.set_ylabel('Correlation Coefficient', fontsize=12)
        ax1.set_ylim(0, 1)
        ax1.grid(True, alpha=0.3)
        
        # Add value labels on bars
        for bar, val in zip(bars, correlations_clean):
            ax1.text(bar.get_x() + bar.get_width()/2, bar.get_height() + 0.02,
                    f'{val:.3f}', ha='center', va='bottom', fontweight='bold')
        
        # Plot 2: Sample Size by Period
        sample_sizes = df['Sample_Size'].tolist()
        plot_sizes = [s for s in sample_sizes if not pd.isna(s)]
        
        ax2.bar(periods_clean, plot_sizes, 
               color=['#E74C3C', '#F39C12', '#27AE60'], alpha=0.8)
        ax2.set_title('Sample Size by Period', fontsize=14, fontweight='bold')
        ax2.set_ylabel('Number of Observations', fontsize=12)
        ax2.grid(True, alpha=0.3)
        
        # Add value labels
        for i, (period, size) in enumerate(zip(periods_clean, plot_sizes)):
            ax2.text(i, size + 1, f'{int(size)}', ha='center', va='bottom', fontweight='bold')
        
        plt.tight_layout()
        plt.show()
        
        # Display the table data
        print("\n" + "="*60)
        print("TABLE 3: BILATERAL STRATEGIC CORRELATION")
        print("="*60)
        print(df.to_string(index=False, float_format='%.3f'))
        print("\nNotes: *** p<0.01, ** p<0.05, * p<0.1")
        print("Trump 2.0 correlation reflects immediate full coverage by both parties.")
        
    except FileNotFoundError:
        print(f"❌ {csv_file} not found")
    except Exception as e:
        print(f"❌ Error plotting bilateral correlation: {e}")

def plot_response_timing(csv_file='table4_response_timing_hazard.csv'):
    """
    Plot Table 4: Response Timing Analysis (Hazard Model)
    """
    try:
        df = pd.read_csv(csv_file)
        
        fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(15, 6))
        
        # Plot 1: Coefficients
        variables = df['Variable'].tolist()
        coefficients = df['Coefficient'].tolist()
        std_errors = df['Std_Error'].tolist()
        
        y_pos = np.arange(len(variables))
        
        bars = ax1.barh(y_pos, coefficients, xerr=std_errors, 
                       color=['#2F5597' if c > 0 else '#E74C3C' for c in coefficients],
                       alpha=0.7, capsize=5)
        
        ax1.set_yticks(y_pos)
        ax1.set_yticklabels(variables)
        ax1.set_xlabel('Coefficient Value', fontsize=12)
        ax1.set_title('Model Coefficients with Standard Errors', fontsize=14, fontweight='bold')
        ax1.axvline(x=0, color='black', linestyle='--', alpha=0.5)
        ax1.grid(True, alpha=0.3)
        
        # Plot 2: Hazard Ratios
        hazard_ratios = df['Hazard_Ratio'].tolist()
        hr_lower = df['HR_CI_Lower'].tolist()
        hr_upper = df['HR_CI_Upper'].tolist()
        
        # Calculate error bars for hazard ratios
        yerr_lower = [hr - lower for hr, lower in zip(hazard_ratios, hr_lower)]
        yerr_upper = [upper - hr for hr, upper in zip(hazard_ratios, hr_upper)]
        
        bars2 = ax2.barh(y_pos, hazard_ratios, 
                        xerr=[yerr_lower, yerr_upper],
                        color=['#27AE60' if hr > 1 else '#E67E22' for hr in hazard_ratios],
                        alpha=0.7, capsize=5)
        
        ax2.set_yticks(y_pos)
        ax2.set_yticklabels(variables)
        ax2.set_xlabel('Hazard Ratio', fontsize=12)
        ax2.set_title('Hazard Ratios with 95% CI', fontsize=14, fontweight='bold')
        ax2.axvline(x=1, color='black', linestyle='--', alpha=0.5)
        ax2.grid(True, alpha=0.3)
        
        plt.tight_layout()
        plt.show()
        
        # Display the table data
        print("\n" + "="*80)
        print("TABLE 4: RESPONSE TIMING ANALYSIS (HAZARD MODEL)")
        print("="*80)
        print(df.to_string(index=False, float_format='%.3f'))
        print("\nNotes: Gamma regression with log link. Hazard ratios >1 indicate slower responses.")
        print("*** p<0.01, ** p<0.05, * p<0.1")
        
    except FileNotFoundError:
        print(f"❌ {csv_file} not found")
    except Exception as e:
        print(f"❌ Error plotting response timing: {e}")

def plot_sectoral_targeting(csv_file='table5_sectoral_targeting_evolution.csv'):
    """
    Plot Table 5: Sectoral Targeting Evolution
    """
    try:
        df = pd.read_csv(csv_file)
        
        fig, ((ax1, ax2), (ax3, ax4)) = plt.subplots(2, 2, figsize=(16, 12))
        
        # Plot 1: Trade Value by Sector
        sectors = df['Sector'].tolist()
        trade_values = df['Trump1_Trade_Value_B'].tolist()
        
        ax1.barh(sectors, trade_values, color='#2F5597', alpha=0.8)
        ax1.set_xlabel('Trade Value (Billions USD)', fontsize=12)
        ax1.set_title('Trump 1.0 Trade Value by Sector', fontsize=14, fontweight='bold')
        ax1.grid(True, alpha=0.3)
        
        # Plot 2: Trade Decline 2017-2020
        trade_decline = df['Trade_Decline_2017_2020'].tolist()
        colors = ['#E74C3C' if x > 0 else '#27AE60' for x in trade_decline]
        
        ax2.barh(sectors, trade_decline, color=colors, alpha=0.8)
        ax2.set_xlabel('Trade Decline (Billions USD)', fontsize=12)
        ax2.set_title('Trade Decline 2017-2020 by Sector', fontsize=14, fontweight='bold')
        ax2.axvline(x=0, color='black', linestyle='--', alpha=0.5)
        ax2.grid(True, alpha=0.3)
        
        # Plot 3: Coverage Proxy
        coverage_proxy = df['Coverage_Proxy'].tolist()
        
        ax3.barh(sectors, coverage_proxy, color='#F39C12', alpha=0.8)
        ax3.set_xlabel('Coverage Proxy', fontsize=12)
        ax3.set_title('Targeting Impact (Coverage Proxy)', fontsize=14, fontweight='bold')
        ax3.grid(True, alpha=0.3)
        
        # Plot 4: Products Count
        products_count = df['Products_Count'].tolist()
        
        ax4.barh(sectors, products_count, color='#9B59B6', alpha=0.8)
        ax4.set_xlabel('Number of Products', fontsize=12)
        ax4.set_title('Products Count by Sector', fontsize=14, fontweight='bold')
        ax4.grid(True, alpha=0.3)
        
        plt.tight_layout()
        plt.show()
        
        # Create a correlation heatmap
        fig2, ax5 = plt.subplots(figsize=(10, 8))
        
        # Select numeric columns for correlation
        numeric_cols = ['Trump1_Trade_Value_B', 'Trade_Decline_2017_2020', 
                       'Coverage_Proxy', 'Products_Count', 'Avg_2017_Value', 'Avg_2020_Value']
        corr_data = df[numeric_cols].corr()
        
        sns.heatmap(corr_data, annot=True, cmap='RdBu_r', center=0, 
                   square=True, ax=ax5, cbar_kws={'label': 'Correlation'})
        ax5.set_title('Sectoral Variables Correlation Matrix', fontsize=14, fontweight='bold')
        plt.tight_layout()
        plt.show()
        
        # Display the table data
        print("\n" + "="*100)
        print("TABLE 5: SECTORAL TARGETING EVOLUTION")
        print("="*100)
        print(df.to_string(index=False, float_format='%.3f'))
        print("\nNotes: Coverage Proxy = (2017 Trade - 2020 Trade) / 2017 Trade.")
        print("Higher values indicate greater targeting impact.")
        
    except FileNotFoundError:
        print(f"❌ {csv_file} not found")
    except Exception as e:
        print(f"❌ Error plotting sectoral targeting: {e}")

def plot_blsi_components():
    """
    Plot the BLSI components from the document
    """
    # Data from the document image
    data = {
        'Component': ['Symmetry (S)', 'Lag Consistency (L)', 'Stability (T)', 'BLSI (equal weights)'],
        'Trump_1_0': [0.847, 0.634, 0.723, 0.735],
        'Trump_2_0': [0.923, 0.891, 0.856, 0.890],
        'Learning_Effect': [0.076, 0.257, 0.133, 0.155],
        'Significance': ['', '***', '**', '***']
    }
    
    df = pd.DataFrame(data)
    
    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(15, 6))
    
    # Plot 1: Component Values Comparison
    x = np.arange(len(df['Component']))
    width = 0.35
    
    bars1 = ax1.bar(x - width/2, df['Trump_1_0'], width, label='Trump 1.0', 
                   color='#3498DB', alpha=0.8)
    bars2 = ax1.bar(x + width/2, df['Trump_2_0'], width, label='Trump 2.0', 
                   color='#E74C3C', alpha=0.8)
    
    ax1.set_xlabel('BLSI Components', fontsize=12)
    ax1.set_ylabel('Component Value', fontsize=12)
    ax1.set_title('BLSI Components: Trump 1.0 vs Trump 2.0', fontsize=14, fontweight='bold')
    ax1.set_xticks(x)
    ax1.set_xticklabels(df['Component'], rotation=45, ha='right')
    ax1.legend()
    ax1.grid(True, alpha=0.3)
    ax1.set_ylim(0, 1)
    
    # Add value labels on bars
    for bar in bars1:
        height = bar.get_height()
        ax1.text(bar.get_x() + bar.get_width()/2., height + 0.01,
                f'{height:.3f}', ha='center', va='bottom', fontsize=10)
    
    for bar in bars2:
        height = bar.get_height()
        ax1.text(bar.get_x() + bar.get_width()/2., height + 0.01,
                f'{height:.3f}', ha='center', va='bottom', fontsize=10)
    
    # Plot 2: Learning Effect
    learning_effects = df['Learning_Effect'].tolist()
    significance = df['Significance'].tolist()
    
    colors = ['#27AE60' if sig == '***' else '#F39C12' if sig == '**' else '#95A5A6' 
              for sig in significance]
    
    bars3 = ax2.bar(x, learning_effects, color=colors, alpha=0.8)
    ax2.set_xlabel('BLSI Components', fontsize=12)
    ax2.set_ylabel('Learning Effect', fontsize=12)
    ax2.set_title('Learning Effect by Component', fontsize=14, fontweight='bold')
    ax2.set_xticks(x)
    ax2.set_xticklabels(df['Component'], rotation=45, ha='right')
    ax2.grid(True, alpha=0.3)
    
    # Add significance stars
    for bar, effect, sig in zip(bars3, learning_effects, significance):
        ax2.text(bar.get_x() + bar.get_width()/2., bar.get_height() + 0.005,
                f'{effect:.3f}{sig}', ha='center', va='bottom', fontsize=10, fontweight='bold')
    
    plt.tight_layout()
    plt.show()
    
    # Display table
    print("\n" + "="*70)
    print("BILATERAL LEARNING STRENGTH INDEX (BLSI) COMPONENTS")
    print("="*70)
    print(df.to_string(index=False))
    print("\nStandard errors in parentheses. *** p<0.01, ** p<0.05, * p<0.1")

def plot_response_timing_data(csv_file='table4_response_timing_hazard.csv'):
    """
    Plot Table 4: Response Timing Analysis
    """
    try:
        df = pd.read_csv(csv_file)
        
        fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(15, 6))
        
        # Plot 1: Coefficients with Error Bars
        variables = df['Variable'].tolist()
        coefficients = df['Coefficient'].tolist()
        std_errors = df['Std_Error'].tolist()
        
        y_pos = np.arange(len(variables))
        
        colors = ['#2F5597' if c > 0 else '#E74C3C' for c in coefficients]
        bars = ax1.barh(y_pos, coefficients, xerr=std_errors, 
                       color=colors, alpha=0.7, capsize=5)
        
        ax1.set_yticks(y_pos)
        ax1.set_yticklabels(variables)
        ax1.set_xlabel('Coefficient Value', fontsize=12)
        ax1.set_title('Model Coefficients with Standard Errors', fontsize=14, fontweight='bold')
        ax1.axvline(x=0, color='black', linestyle='--', alpha=0.5)
        ax1.grid(True, alpha=0.3)
        
        # Plot 2: Hazard Ratios with CI
        hazard_ratios = df['Hazard_Ratio'].tolist()
        hr_lower = df['HR_CI_Lower'].tolist()
        hr_upper = df['HR_CI_Upper'].tolist()
        
        # Calculate error bars
        yerr_lower = [hr - lower for hr, lower in zip(hazard_ratios, hr_lower)]
        yerr_upper = [upper - hr for hr, upper in zip(hazard_ratios, hr_upper)]
        
        colors2 = ['#27AE60' if hr > 1 else '#E67E22' for hr in hazard_ratios]
        bars2 = ax2.barh(y_pos, hazard_ratios, 
                        xerr=[yerr_lower, yerr_upper],
                        color=colors2, alpha=0.7, capsize=5)
        
        ax2.set_yticks(y_pos)
        ax2.set_yticklabels(variables)
        ax2.set_xlabel('Hazard Ratio', fontsize=12)
        ax2.set_title('Hazard Ratios with 95% CI', fontsize=14, fontweight='bold')
        ax2.axvline(x=1, color='black', linestyle='--', alpha=0.5)
        ax2.grid(True, alpha=0.3)
        
        plt.tight_layout()
        plt.show()
        
        # Display table
        print("\n" + "="*90)
        print("TABLE 4: RESPONSE TIMING ANALYSIS (HAZARD MODEL)")
        print("="*90)
        print(df.to_string(index=False, float_format='%.3f'))
        print("\nNotes: Gamma regression with log link. Hazard ratios >1 indicate slower responses.")
        print("*** p<0.01, ** p<0.05, * p<0.1")
        
    except FileNotFoundError:
        print(f"❌ {csv_file} not found")
    except Exception as e:
        print(f"❌ Error plotting response timing: {e}")

def plot_sectoral_evolution_data(csv_file='table5_sectoral_targeting_evolution.csv'):
    """
    Plot Table 5: Sectoral Targeting Evolution
    """
    try:
        df = pd.read_csv(csv_file)
        
        # Create comprehensive visualization
        fig = plt.figure(figsize=(18, 12))
        
        # Plot 1: Trade Value vs Coverage Proxy (top left)
        ax1 = plt.subplot(2, 3, 1)
        scatter = ax1.scatter(df['Trump1_Trade_Value_B'], df['Coverage_Proxy'], 
                             s=df['Products_Count']/20, alpha=0.7, 
                             c=df['Trade_Decline_2017_2020'], cmap='RdYlBu_r')
        ax1.set_xlabel('Trump 1.0 Trade Value (Billions)', fontsize=11)
        ax1.set_ylabel('Coverage Proxy', fontsize=11)
        ax1.set_title('Trade Value vs Targeting Impact', fontsize=12, fontweight='bold')
        ax1.grid(True, alpha=0.3)
        
        # Add colorbar
        cbar = plt.colorbar(scatter, ax=ax1)
        cbar.set_label('Trade Decline 2017-2020', fontsize=10)
        
        # Annotate key sectors
        for i, sector in enumerate(df['Sector']):
            if df.iloc[i]['Coverage_Proxy'] > 0.2 or df.iloc[i]['Trump1_Trade_Value_B'] > 200:
                ax1.annotate(sector, (df.iloc[i]['Trump1_Trade_Value_B'], df.iloc[i]['Coverage_Proxy']),
                           xytext=(5, 5), textcoords='offset points', fontsize=9)
        
        # Plot 2: Coverage Proxy by Sector (top middle)
        ax2 = plt.subplot(2, 3, 2)
        coverage_sorted = df.sort_values('Coverage_Proxy', ascending=True)
        bars = ax2.barh(coverage_sorted['Sector'], coverage_sorted['Coverage_Proxy'],
                       color='#E74C3C', alpha=0.8)
        ax2.set_xlabel('Coverage Proxy', fontsize=11)
        ax2.set_title('Targeting Impact by Sector', fontsize=12, fontweight='bold')
        ax2.grid(True, alpha=0.3)
        
        # Plot 3: Trade Decline Distribution (top right)
        ax3 = plt.subplot(2, 3, 3)
        decline_sorted = df.sort_values('Trade_Decline_2017_2020', ascending=True)
        colors3 = ['#E74C3C' if x > 0 else '#27AE60' for x in decline_sorted['Trade_Decline_2017_2020']]
        ax3.barh(decline_sorted['Sector'], decline_sorted['Trade_Decline_2017_2020'],
                color=colors3, alpha=0.8)
        ax3.set_xlabel('Trade Decline (Billions)', fontsize=11)
        ax3.set_title('Trade Decline 2017-2020', fontsize=12, fontweight='bold')
        ax3.axvline(x=0, color='black', linestyle='--', alpha=0.5)
        ax3.grid(True, alpha=0.3)
        
        # Plot 4: Before/After Trade Values (bottom left)
        ax4 = plt.subplot(2, 3, 4)
        x_sectors = np.arange(len(df))
        width = 0.35
        
        bars1 = ax4.bar(x_sectors - width/2, df['Avg_2017_Value'], width,
                       label='2017 Value', color='#3498DB', alpha=0.8)
        bars2 = ax4.bar(x_sectors + width/2, df['Avg_2020_Value'], width,
                       label='2020 Value', color='#E74C3C', alpha=0.8)
        
        ax4.set_xlabel('Sector', fontsize=11)
        ax4.set_ylabel('Average Trade Value', fontsize=11)
        ax4.set_title('Trade Values: 2017 vs 2020', fontsize=12, fontweight='bold')
        ax4.set_xticks(x_sectors)
        ax4.set_xticklabels(df['Sector'], rotation=45, ha='right')
        ax4.legend()
        ax4.grid(True, alpha=0.3)
        
        # Plot 5: Products Count vs Trade Impact (bottom middle)
        ax5 = plt.subplot(2, 3, 5)
        ax5.scatter(df['Products_Count'], df['Coverage_Proxy'], 
                   s=df['Trump1_Trade_Value_B']*2, alpha=0.7,
                   c=df['Trade_Decline_2017_2020'], cmap='RdYlBu_r')
        ax5.set_xlabel('Products Count', fontsize=11)
        ax5.set_ylabel('Coverage Proxy', fontsize=11)
        ax5.set_title('Products vs Targeting Impact', fontsize=12, fontweight='bold')
        ax5.grid(True, alpha=0.3)
        
        # Plot 6: Summary Statistics (bottom right)
        ax6 = plt.subplot(2, 3, 6)
        ax6.axis('off')
        
        # Summary statistics
        summary_text = f"""
        SECTORAL TARGETING SUMMARY
        
        Total Sectors: {len(df)}
        Avg Trade Value 2017: ${df['Avg_2017_Value'].mean():.2f}B
        Avg Trade Value 2020: ${df['Avg_2020_Value'].mean():.2f}B
        Total Trade Decline: ${df['Trade_Decline_2017_2020'].sum():.2f}B
        
        Highest Impact Sectors:
        {df.nlargest(3, 'Coverage_Proxy')['Sector'].tolist()}
        
        Most Affected by Volume:
        {df.nlargest(3, 'Trade_Decline_2017_2020')['Sector'].tolist()}
        """
        
        ax6.text(0.1, 0.9, summary_text, fontsize=11, verticalalignment='top',
                bbox=dict(boxstyle="round,pad=0.3", facecolor='lightblue', alpha=0.5))
        
        plt.tight_layout()
        plt.show()
        
        # Display the table data
        print("\n" + "="*120)
        print("TABLE 5: SECTORAL TARGETING EVOLUTION")
        print("="*120)
        print(df.to_string(index=False, float_format='%.3f'))
        print("\nNotes: Coverage Proxy = (2017 Trade - 2020 Trade) / 2017 Trade.")
        print("Higher values indicate greater targeting impact.")
        
    except FileNotFoundError:
        print(f"❌ {csv_file} not found")
    except Exception as e:
        print(f"❌ Error plotting sectoral evolution: {e}")

def plot_all_data():
    """
    Plot all CSV data with academic-style visualizations
    """
    print("""
    📊 ACADEMIC DATA VISUALIZATION SUITE
    ===================================
    Creating interactive plots for trade war analysis data
    """)
    
    # Plot all tables
    print("\n🔍 Analyzing Bilateral Strategic Correlation...")
    plot_bilateral_correlation()
    
    print("\n⏱️ Analyzing Response Timing Patterns...")
    plot_response_timing_data()
    
    print("\n🎯 Analyzing Sectoral Targeting Evolution...")
    plot_sectoral_evolution_data()
    
    print("\n📈 Displaying BLSI Components...")
    plot_blsi_components()
    
    print("""
    ✅ ANALYSIS COMPLETE
    All data has been visualized with academic-quality plots
    """)

def display_csv_summary():
    """
    Display summary information about all CSV files
    """
    csv_files = [
        'table3_bilateral_correlation.csv',
        'table4_response_timing_hazard.csv', 
        'table5_sectoral_targeting_evolution.csv'
    ]
    
    print("\n📋 CSV FILES SUMMARY")
    print("="*50)
    
    for csv_file in csv_files:
        try:
            df = pd.read_csv(csv_file)
            print(f"\n📄 {csv_file}")
            print(f"   Rows: {len(df)}")
            print(f"   Columns: {len(df.columns)}")
            print(f"   Column names: {list(df.columns)}")
        except FileNotFoundError:
            print(f"\n❌ {csv_file} - File not found")
        except Exception as e:
            print(f"\n❌ {csv_file} - Error: {e}")

# Main execution functions
if __name__ == "__main__":
    print("""
    📊 ACADEMIC CSV DATA PLOTTER
    ===========================
    Plotting trade war analysis data in academic format
    """)
    
    # First show summary of available data
    display_csv_summary()
    
    # Then create all visualizations
    plot_all_data()
    
    print("""
    🎯 PLOTTING COMPLETE
    All academic tables have been visualized
    Use individual functions to plot specific tables:
    - plot_bilateral_correlation()
    - plot_response_timing_data() 
    - plot_sectoral_evolution_data()
    - plot_blsi_components()
    """)