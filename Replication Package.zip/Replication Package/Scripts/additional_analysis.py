#!/usr/bin/env python3
"""
ADDITIONAL ANALYSIS FUNCTIONS FOR BILATERAL LEARNING STUDY
Tables 3, 4, and 5: Strategic Correlation, Response Timing, and Sectoral Evolution
"""

import pandas as pd
import numpy as np
from scipy import stats
from scipy.stats import gamma
import statsmodels.api as sm
from sklearn.linear_model import GammaRegressor
import warnings
warnings.filterwarnings('ignore')

def bilateral_strategic_correlation_analysis(analyzer):
    """
    Table 3: Bilateral Strategic Correlation
    Measure how closely US and China tariff coverage moved together over time
    """
    print("\n" + "="*70)
    print("TABLE 3: BILATERAL STRATEGIC CORRELATION ANALYSIS")
    print("="*70)
    
    panel_b = analyzer.data['panel_b_clean'].copy()
    
    # Calculate correlation by period with confidence intervals
    correlation_results = []
    
    periods = ['Trump 1.0', 'Biden', 'Trump 2.0']
    
    for period in periods:
        period_data = panel_b[panel_b['period'] == period]
        
        if len(period_data) < 3:
            continue
            
        us_coverage = period_data['Chinese exports subject to US tariffs']
        china_coverage = period_data['US exports subject to Chinese tariffs']
        
        # Remove any NaN values
        valid_data = pd.DataFrame({'us': us_coverage, 'china': china_coverage}).dropna()
        
        if len(valid_data) < 3:
            continue
            
        # Calculate Pearson correlation
        correlation, p_value = stats.pearsonr(valid_data['us'], valid_data['china'])
        
        # Calculate confidence interval using Fisher transformation
        n = len(valid_data)
        if n > 3:
            fisher_z = np.arctanh(correlation)
            se = 1 / np.sqrt(n - 3)
            ci_lower = np.tanh(fisher_z - 1.96 * se)
            ci_upper = np.tanh(fisher_z + 1.96 * se)
        else:
            ci_lower, ci_upper = np.nan, np.nan
        
        correlation_results.append({
            'Period': period,
            'Correlation': correlation,
            'Sample_Size': n,
            'P_Value': p_value,
            'CI_Lower': ci_lower,
            'CI_Upper': ci_upper,
            'Significance': '***' if p_value < 0.001 else '**' if p_value < 0.01 else '*' if p_value < 0.05 else ''
        })
    
    # Overall correlation
    valid_overall = panel_b[['Chinese exports subject to US tariffs', 
                            'US exports subject to Chinese tariffs']].dropna()
    
    if len(valid_overall) > 3:
        overall_corr, overall_p = stats.pearsonr(
            valid_overall['Chinese exports subject to US tariffs'],
            valid_overall['US exports subject to Chinese tariffs']
        )
        
        n_overall = len(valid_overall)
        fisher_z = np.arctanh(overall_corr)
        se = 1 / np.sqrt(n_overall - 3)
        ci_lower = np.tanh(fisher_z - 1.96 * se)
        ci_upper = np.tanh(fisher_z + 1.96 * se)
        
        correlation_results.append({
            'Period': 'Overall',
            'Correlation': overall_corr,
            'Sample_Size': n_overall,
            'P_Value': overall_p,
            'CI_Lower': ci_lower,
            'CI_Upper': ci_upper,
            'Significance': '***' if overall_p < 0.001 else '**' if overall_p < 0.01 else '*' if overall_p < 0.05 else ''
        })
    
    correlation_df = pd.DataFrame(correlation_results)
    
    print("\nBilateral Strategic Correlation Results:")
    print("-" * 70)
    print(f"{'Period':<15} {'Correlation':<12} {'95% CI':<20} {'N':<6} {'Sig':<5}")
    print("-" * 70)
    
    for _, row in correlation_df.iterrows():
        ci_str = f"[{row['CI_Lower']:.3f}, {row['CI_Upper']:.3f}]" if not pd.isna(row['CI_Lower']) else "[N/A]"
        print(f"{row['Period']:<15} {row['Correlation']:<12.3f} {ci_str:<20} {row['Sample_Size']:<6.0f} {row['Significance']:<5}")
    
    # Export results
    correlation_df.to_csv('table3_bilateral_correlation.csv', index=False)
    print("\n✓ Table 3 exported to: table3_bilateral_correlation.csv")
    
    return correlation_df

def response_timing_hazard_analysis(analyzer):
    """
    Table 4: Response Timing Analysis (Hazard Model Approximation)
    Estimate how quickly China retaliated and whether speed changed in Trump 2.0
    """
    print("\n" + "="*70)
    print("TABLE 4: RESPONSE TIMING ANALYSIS (HAZARD MODEL APPROXIMATION)")
    print("="*70)
    
    # Create response dataset from existing timing analysis
    if 'timing_analysis' not in analyzer.results or analyzer.results['timing_analysis'].empty:
        print("⚠ No timing analysis data available. Running basic analysis...")
        return pd.DataFrame()
    
    timing_data = analyzer.results['timing_analysis'].copy()
    
    # Add Trump 2.0 indicator
    trump_2_start = pd.to_datetime('2025-01-20')
    timing_data['Round2'] = (timing_data['us_action_date'] >= trump_2_start).astype(int)
    
    # Create additional features for hazard model
    timing_data['action_sequence'] = range(1, len(timing_data) + 1)
    timing_data['log_us_products'] = np.log(timing_data['us_products'] + 1)
    timing_data['escalation_size'] = timing_data['us_products'] / 1000  # Scale down for regression
    
    # Add economic uncertainty proxy (volatility in prior responses)
    timing_data['uncertainty'] = timing_data['response_days'].rolling(window=3, min_periods=1).std().fillna(0)
    
    # Prepare response time data (Gamma regression as hazard model proxy)
    # Gamma distribution is appropriate for positive, continuous duration data
    
    if len(timing_data) < 5:
        print("⚠ Insufficient data for hazard model analysis")
        return pd.DataFrame()
    
    # Features for the model
    X_features = timing_data[['Round2', 'escalation_size', 'action_sequence', 'uncertainty']].fillna(0)
    y_response = timing_data['response_days']
    
    # Add constant for intercept
    X_with_const = sm.add_constant(X_features)
    
    try:
        # Fit Gamma GLM (log link function)
        gamma_model = sm.GLM(y_response, X_with_const, 
                           family=sm.families.Gamma(link=sm.families.links.log()))
        gamma_results = gamma_model.fit()
        
        # Create results table
        hazard_results = []
        
        var_names = ['Intercept', 'Trump_2.0_Indicator', 'Escalation_Size', 
                    'Action_Sequence', 'Economic_Uncertainty']
        
        for i, var_name in enumerate(var_names):
            coef = gamma_results.params.iloc[i]
            se = gamma_results.bse.iloc[i]
            p_val = gamma_results.pvalues.iloc[i]
            ci_lower = gamma_results.conf_int().iloc[i, 0]
            ci_upper = gamma_results.conf_int().iloc[i, 1]
            
            # Convert to hazard ratios (exp of coefficients for interpretation)
            hazard_ratio = np.exp(coef)
            hr_ci_lower = np.exp(ci_lower)
            hr_ci_upper = np.exp(ci_upper)
            
            hazard_results.append({
                'Variable': var_name,
                'Coefficient': coef,
                'Std_Error': se,
                'P_Value': p_val,
                'CI_Lower': ci_lower,
                'CI_Upper': ci_upper,
                'Hazard_Ratio': hazard_ratio,
                'HR_CI_Lower': hr_ci_lower,
                'HR_CI_Upper': hr_ci_upper,
                'Significance': '***' if p_val < 0.001 else '**' if p_val < 0.01 else '*' if p_val < 0.05 else ''
            })
        
        hazard_df = pd.DataFrame(hazard_results)
        
        print("\nResponse Timing Hazard Model Results:")
        print("-" * 90)
        print(f"{'Variable':<20} {'Coef':<8} {'SE':<8} {'HR':<8} {'95% CI (HR)':<15} {'p-val':<8} {'Sig':<5}")
        print("-" * 90)
        
        for _, row in hazard_df.iterrows():
            hr_ci = f"[{row['HR_CI_Lower']:.2f}, {row['HR_CI_Upper']:.2f}]"
            print(f"{row['Variable']:<20} {row['Coefficient']:<8.3f} {row['Std_Error']:<8.3f} "
                  f"{row['Hazard_Ratio']:<8.3f} {hr_ci:<15} {row['P_Value']:<8.3f} {row['Significance']:<5}")
        
        print(f"\nModel Statistics:")
        print(f"Log-likelihood: {gamma_results.llf:.2f}")
        print(f"AIC: {gamma_results.aic:.2f}")
        print(f"Sample size: {len(timing_data)}")
        
        # Interpretation
        trump2_effect = hazard_df[hazard_df['Variable'] == 'Trump_2.0_Indicator']['Hazard_Ratio'].iloc[0]
        if trump2_effect < 1:
            print(f"\n→ LEARNING EFFECT: Trump 2.0 responses {(1-trump2_effect)*100:.1f}% faster")
        else:
            print(f"\n→ ESCALATION EFFECT: Trump 2.0 responses {(trump2_effect-1)*100:.1f}% slower")
        
        # Export results
        hazard_df.to_csv('table4_response_timing_hazard.csv', index=False)
        print("✓ Table 4 exported to: table4_response_timing_hazard.csv")
        
        return hazard_df
        
    except Exception as e:
        print(f"⚠ Error in hazard model fitting: {e}")
        print("Using simplified timing analysis...")
        
        # Simplified analysis if full model fails
        simple_results = []
        for period in ['Trump 1.0', 'Trump 2.0']:
            period_timing = timing_data[timing_data['Round2'] == (1 if period == 'Trump 2.0' else 0)]
            if not period_timing.empty:
                avg_response = period_timing['response_days'].mean()
                std_response = period_timing['response_days'].std()
                n = len(period_timing)
                
                simple_results.append({
                    'Period': period,
                    'Avg_Response_Days': avg_response,
                    'Std_Dev': std_response,
                    'Sample_Size': n
                })
        
        return pd.DataFrame(simple_results)

def sectoral_targeting_evolution_analysis(analyzer):
    """
    Table 5: Sectoral Targeting Evolution
    Compare how China's retaliation patterns evolved across sectors
    """
    print("\n" + "="*70)
    print("TABLE 5: SECTORAL TARGETING EVOLUTION ANALYSIS")
    print("="*70)
    
    # We'll use the trade data to approximate sectoral analysis
    us_imports = analyzer.data['us_imports'].copy()
    us_exports = analyzer.data['us_exports'].copy() if 'us_exports' in analyzer.data else None
    
    # Create sector mapping based on HS codes (simplified version)
    def map_hs_to_sector(hs_code):
        hs_str = str(hs_code)[:2] if pd.notna(hs_code) else '00'
        
        sector_mapping = {
            '01': 'Agriculture', '02': 'Agriculture', '03': 'Agriculture', '04': 'Agriculture',
            '05': 'Agriculture', '06': 'Agriculture', '07': 'Agriculture', '08': 'Agriculture',
            '09': 'Agriculture', '10': 'Agriculture', '11': 'Agriculture', '12': 'Agriculture',
            '13': 'Agriculture', '14': 'Agriculture', '15': 'Agriculture',
            '25': 'Raw_Materials', '26': 'Raw_Materials', '27': 'Raw_Materials',
            '28': 'Chemicals', '29': 'Chemicals', '30': 'Chemicals', '31': 'Chemicals',
            '32': 'Chemicals', '33': 'Chemicals', '34': 'Chemicals', '35': 'Chemicals',
            '36': 'Chemicals', '37': 'Chemicals', '38': 'Chemicals',
            '39': 'Plastics', '40': 'Plastics',
            '50': 'Textiles', '51': 'Textiles', '52': 'Textiles', '53': 'Textiles',
            '54': 'Textiles', '55': 'Textiles', '56': 'Textiles', '57': 'Textiles',
            '58': 'Textiles', '59': 'Textiles', '60': 'Textiles', '61': 'Textiles',
            '62': 'Textiles', '63': 'Textiles',
            '72': 'Steel_Metals', '73': 'Steel_Metals', '74': 'Steel_Metals',
            '75': 'Steel_Metals', '76': 'Steel_Metals', '78': 'Steel_Metals',
            '79': 'Steel_Metals', '80': 'Steel_Metals', '81': 'Steel_Metals',
            '82': 'Steel_Metals', '83': 'Steel_Metals',
            '84': 'Technology', '85': 'Technology',
            '86': 'Transportation', '87': 'Transportation', '88': 'Transportation',
            '89': 'Transportation',
            '90': 'Precision_Instruments', '91': 'Precision_Instruments',
            '92': 'Precision_Instruments', '94': 'Furniture', '95': 'Toys_Sports'
        }
        
        return sector_mapping.get(hs_str, 'Other')
    
    # Add sector classification
    us_imports['Sector'] = us_imports['HS10'].apply(lambda x: map_hs_to_sector(str(x)[:2] if pd.notna(x) else '00'))
    
    # Calculate sectoral trade values and changes
    sectors = us_imports['Sector'].unique()
    sectoral_results = []
    
    for sector in sectors:
        sector_data = us_imports[us_imports['Sector'] == sector]
        
        # Calculate trade values by period
        trump_1_trade = sector_data[['imp2017', 'imp2018', 'imp2019', 'imp2020']].sum().sum()
        
        # Calculate coverage (simplified - using trade decline as proxy for tariff impact)
        trade_2017 = sector_data['imp2017'].sum()
        trade_2020 = sector_data['imp2020'].sum()
        
        if trade_2017 > 0:
            coverage_proxy = max(0, (trade_2017 - trade_2020) / trade_2017)
        else:
            coverage_proxy = 0
        
        # Calculate targeting intensity (products affected)
        products_in_sector = len(sector_data)
        
        sectoral_results.append({
            'Sector': sector,
            'Trump1_Trade_Value_B': trump_1_trade / 1e6,  # Convert to billions
            'Trade_Decline_2017_2020': (trade_2017 - trade_2020) / 1e6,
            'Coverage_Proxy': coverage_proxy,
            'Products_Count': products_in_sector,
            'Avg_2017_Value': trade_2017 / 1e6,
            'Avg_2020_Value': trade_2020 / 1e6
        })
    
    sectoral_df = pd.DataFrame(sectoral_results)
    
    # Sort by trade decline (most targeted sectors first)
    sectoral_df = sectoral_df.sort_values('Trade_Decline_2017_2020', ascending=False)
    
    print("\nSectoral Targeting Evolution Results:")
    print("-" * 100)
    print(f"{'Sector':<18} {'2017 Value':<12} {'2020 Value':<12} {'Decline':<12} {'Coverage':<10} {'Products':<10}")
    print(f"{'':18} {'($B)':<12} {'($B)':<12} {'($B)':<12} {'Proxy':<10} {'Count':<10}")
    print("-" * 100)
    
    for _, row in sectoral_df.head(10).iterrows():
        print(f"{row['Sector']:<18} {row['Avg_2017_Value']:<12.1f} {row['Avg_2020_Value']:<12.1f} "
              f"{row['Trade_Decline_2017_2020']:<12.1f} {row['Coverage_Proxy']:<10.3f} {row['Products_Count']:<10.0f}")
    
    # Calculate strategic targeting metrics
    high_impact_sectors = sectoral_df[sectoral_df['Coverage_Proxy'] > 0.3]
    
    print(f"\nStrategic Targeting Analysis:")
    print(f"High-impact sectors (>30% coverage proxy): {len(high_impact_sectors)}")
    print(f"Most targeted sector: {sectoral_df.iloc[0]['Sector']} ({sectoral_df.iloc[0]['Coverage_Proxy']:.1%} coverage proxy)")
    print(f"Total trade decline: ${sectoral_df['Trade_Decline_2017_2020'].sum():.1f}B")
    
    # Export results
    sectoral_df.to_csv('table5_sectoral_targeting_evolution.csv', index=False)
    print("✓ Table 5 exported to: table5_sectoral_targeting_evolution.csv")
    
    return sectoral_df

def generate_comprehensive_tables(analyzer):
    """
    Generate all three additional analysis tables
    """
    print("\n" + "="*80)
    print("COMPREHENSIVE BILATERAL LEARNING TABLES GENERATION")
    print("="*80)
    
    # Table 3: Bilateral Strategic Correlation
    correlation_results = bilateral_strategic_correlation_analysis(analyzer)
    
    # Table 4: Response Timing Hazard Analysis  
    timing_results = response_timing_hazard_analysis(analyzer)
    
    # Table 5: Sectoral Targeting Evolution
    sectoral_results = sectoral_targeting_evolution_analysis(analyzer)
    
    # Generate summary insights
    print("\n" + "="*80)
    print("KEY INSIGHTS FROM ADDITIONAL ANALYSIS")
    print("="*80)
    
    if not correlation_results.empty:
        trump1_corr = correlation_results[correlation_results['Period'] == 'Trump 1.0']['Correlation']
        trump2_corr = correlation_results[correlation_results['Period'] == 'Trump 2.0']['Correlation']
        
        if not trump1_corr.empty and not trump2_corr.empty:
            corr_change = trump2_corr.iloc[0] - trump1_corr.iloc[0]
            print(f"BILATERAL COORDINATION CHANGE: {corr_change:+.3f}")
            if corr_change > 0.1:
                print("→ EVIDENCE: Increased strategic coordination in Trump 2.0")
            elif corr_change < -0.1:
                print("→ EVIDENCE: Decreased coordination/more chaotic responses in Trump 2.0")
        
        overall_corr = correlation_results[correlation_results['Period'] == 'Overall']['Correlation']
        if not overall_corr.empty:
            print(f"OVERALL STRATEGIC COUPLING: {overall_corr.iloc[0]:.3f}")
    
    if not timing_results.empty and 'Hazard_Ratio' in timing_results.columns:
        trump2_timing = timing_results[timing_results['Variable'] == 'Trump_2.0_Indicator']
        if not trump2_timing.empty:
            hr = trump2_timing['Hazard_Ratio'].iloc[0]
            if hr < 0.8:
                print(f"RESPONSE SPEED LEARNING: {(1-hr)*100:.1f}% faster responses in Trump 2.0")
            elif hr > 1.2:
                print(f"RESPONSE DELAY EFFECT: {(hr-1)*100:.1f}% slower responses in Trump 2.0")
    
    if not sectoral_results.empty:
        top_targeted = sectoral_results.iloc[0]
        print(f"MOST STRATEGIC TARGETING: {top_targeted['Sector']} sector")
        print(f"SECTORAL CONCENTRATION: {len(sectoral_results[sectoral_results['Coverage_Proxy'] > 0.2])} high-impact sectors")
    
    return {
        'correlation_table': correlation_results,
        'timing_table': timing_results, 
        'sectoral_table': sectoral_results
    }

# Add this function to the main TradeWarLearningAnalysis class
def add_comprehensive_analysis_to_main():
    """
    Integration function to add to the main analysis class
    """
    return """
    
    def run_comprehensive_analysis(self):
        \"\"\"Execute complete analysis including new tables\"\"\"
        print("BILATERAL STRATEGIC LEARNING IN TRADE WARS")
        print("Trump-Xi Strategic Adaptation Analysis - COMPREHENSIVE EDITION")
        print("="*80)
        
        # Original analysis
        self.load_data()
        self.clean_and_prepare_data()
        self.check_trump_2_data()
        self.analyze_trump_learning()
        self.analyze_xi_learning()
        self.analyze_response_timing()
        self.analyze_sectoral_learning()
        self.analyze_strategic_interaction()
        
        # NEW: Additional comprehensive tables
        comprehensive_results = generate_comprehensive_tables(self)
        self.results.update(comprehensive_results)
        
        # Visualizations and reporting
        self.create_visualizations()
        self.generate_research_report()
        self.export_results()
        
        print("\\n" + "="*80)
        print("COMPREHENSIVE ANALYSIS COMPLETE - READY FOR PUBLICATION")
        print("="*80)
    """

# Example usage at the end of the main script:
if __name__ == "__main__":
    print("""
    EXECUTING COMPREHENSIVE BILATERAL LEARNING ANALYSIS
    Adding Tables 3, 4, and 5 to existing framework
    """)
    
    # This would be added to the main execution block
    print("""
    
    # After running the main analysis:
    # analyzer.run_full_analysis()
    
    # Add comprehensive tables:
    comprehensive_results = generate_comprehensive_tables(analyzer)
    analyzer.results.update(comprehensive_results)
    
    print("\\n🎯 COMPREHENSIVE BILATERAL LEARNING ANALYSIS COMPLETE")
    print("📊 All tables (1-5) generated successfully")
    print("📈 Ready for academic publication and policy analysis")
    """)
    