import pandas as pd
from datetime import datetime
import os
import re
import warnings
warnings.filterwarnings("ignore", message="Could not infer format*", category=UserWarning)

# Define Trump phases
phase1_start = datetime(2017, 1, 1)
phase1_end = datetime(2021, 1, 1)
phase2_start = datetime(2025, 1, 1)
phase2_end = datetime(2025, 8, 18)

# Dataset categories and their files
dataset_groups = {
    "Tariff Measures": [
        "2.Tariff Data Raw_China.csv", "2.Tariff Data Raw_US.csv"
    ],
    "Exclusion Lists": [
        "3.Exclusion Data Raw_China_raw.csv", "3.Exclusion Data Raw_US_dates.csv",
        "3.Exclusion Data Raw_US_raw.csv", "3.Exclusion Data Raw_US_wide.csv"
    ],
    "Trade Flows": [
        "4.Trade Data Raw_China exp to US.csv", "4.Trade Data Raw_China imp from US.csv",
        "4.Trade Data Raw_US exp to China.csv", "4.Trade Data Raw_US imp from China.csv",
        "4.Trade Data Raw_USEXp China.csv"
    ],
    "Antidumping Actions": [
        "GAD-CHN_AD-CHN-Domestic-Firms.csv", "GAD-CHN_AD-CHN-Foreign-Firms.csv",
        "GAD-CHN_AD-CHN-Master.csv", "GAD-CHN_AD-CHN-Products.csv",
        "GAD-USA_AD-USA-Domestic-Firms.csv", "GAD-USA_AD-USA-Foreign-Firms.csv",
        "GAD-USA_AD-USA-Master.csv", "GAD-USA_AD-USA-Products.csv",
        "GAD-USA_products-HS.csv"
    ],
    "Countervailing Duties": [
        "GCVD-CHN_CVD-CHN-Domestic-Firms.csv", "GCVD-CHN_CVD-CHN-Foreign-Firms.csv",
        "GCVD-CHN_CVD-CHN-Master.csv", "GCVD-CHN_CVD-CHN-Products.csv",
        "GCVD-USA_CVD_USA_Master.csv", "GCVD-USA_CVD_USA_Products.csv",
        "GCVD-USA_CVD-USA-Domestic-Firms.csv", "GCVD-USA_CVD-USA-Foreign-Firms.csv"
    ],
    "Strategic Panel": [
        "uschinatradewartariffs_Panel-A.csv", "uschinatradewartariffs_Panel-B.csv"
    ]
}

# Helper: extract date from column header
def extract_date_from_header(header):
    match = re.search(r'\b(?:Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)[a-z]*\s+\d{1,2},\s+\d{4}\b', header)
    if match:
        try:
            return datetime.strptime(match.group(), "%B %d, %Y")
        except:
            return None
    match = re.search(r'exp(\d{4})', header)
    if match:
        try:
            return datetime(int(match.group(1)), 1, 1)
        except:
            return None
    return None

# Helper: detect phase coverage
def detect_phase(df, label):
    phases = set()
    if label in ["Tariff Measures", "Trade Flows"]:
        for col in df.columns:
            dt = extract_date_from_header(col)
            if dt:
                if phase1_start <= dt < phase1_end:
                    phases.add("Phase Trump 1.0")
                if phase2_start <= dt <= phase2_end:
                    phases.add("Phase Trump 2.0")
    else:
        date_cols = [col for col in df.columns if any(k in col.lower() for k in ["date", "start", "effective", "imposition"])]
        for col in date_cols:
            try:
                dates = pd.to_datetime(df[col], errors='coerce')
                if dates.between(phase1_start, phase1_end).any():
                    phases.add("Phase Trump 1.0")
                if dates.between(phase2_start, phase2_end).any():
                    phases.add("Phase Trump 2.0")
            except:
                continue
    return ", ".join(sorted(phases)) if phases else "Unknown"

# Helper: infer directionality
def infer_direction(file_name):
    name = file_name.lower()
    if "us" in name and "china" in name:
        if "exp" in name:
            return "US→China"
        elif "imp" in name:
            return "China→US"
        else:
            return "Mixed"
    elif "chn" in name:
        return "China→US"
    elif "usa" in name:
        return "US→China"
    else:
        return "Unknown"

# Build summary
summary = []
total_obs_all, total_cols_all = 0, 0

for label, files in dataset_groups.items():
    total_obs, total_cols = 0, 0
    directions, phases = set(), set()
    for file in files:
        try:
            df = pd.read_csv(file)
            total_obs += len(df)
            total_cols += df.shape[1]
            directions.add(infer_direction(file))
            phase = detect_phase(df, label)
            if phase != "Unknown":
                phases.update(phase.split(", "))
        except:
            continue
    total_obs_all += total_obs
    total_cols_all += total_cols
    summary.append({
        "Dataset Component": label,
        "Total Observations": total_obs,
        "Total Columns": total_cols,
        "Directional Coverage": ", ".join(sorted(directions)) if directions else "Unknown",
        "Phase Coverage": ", ".join(sorted(phases)) if phases else "Unknown"
    })

# Add final total row
summary.append({
    "Dataset Component": "Total",
    "Total Observations": total_obs_all,
    "Total Columns": total_cols_all,
    "Directional Coverage": "",
    "Phase Coverage": ""
})

# Output summary
summary_df = pd.DataFrame(summary)
summary_df.to_csv("table 1_DatasetsSummary.csv", index=False)
print(summary_df)